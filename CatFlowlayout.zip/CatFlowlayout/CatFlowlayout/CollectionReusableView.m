//
//  CollectionReusableView.m
//  CatFlowlayout
//
//  Created by IOS on 16/1/6.
//  Copyright © 2016年 Cat. All rights reserved.
//

#import "CollectionReusableView.h"

@implementation CollectionReusableView

-(instancetype)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI
{
    _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 100)];
    [self addSubview:_imageView];
    
    _label = [[UILabel alloc]initWithFrame:CGRectMake(100, 20, 100, 30)];
    [_imageView addSubview:_label];
}

@end
