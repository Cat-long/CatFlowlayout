//
//  CollectionReusableView.h
//  CatFlowlayout
//
//  Created by IOS on 16/1/6.
//  Copyright © 2016年 Cat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionReusableView : UICollectionReusableView

@property (nonatomic , strong) UIImageView *imageView;
@property (nonatomic , strong) UILabel *label;

@end
