//
//  CollectionViewCell.h
//  CatFlowlayout
//
//  Created by IOS on 16/1/6.
//  Copyright © 2016年 Cat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewCell : UICollectionViewCell

@property (nonatomic , strong) UILabel *label;


@end
