//
//  CollectionViewCell.m
//  CatFlowlayout
//
//  Created by IOS on 16/1/6.
//  Copyright © 2016年 Cat. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell
-(id)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI
{
    _label = [[UILabel alloc]initWithFrame:CGRectMake(10, 10, 100, 30)];
    [self.contentView addSubview:_label];
}

@end
