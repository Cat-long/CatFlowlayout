//
//  ViewController.m
//  CatFlowlayout
//
//  Created by IOS on 16/1/5.
//  Copyright © 2016年 Cat. All rights reserved.
//

#import "ViewController.h"
#import "CatFlowLayout.h"
#import "CollectionReusableView.h"
#import "CollectionViewCell.h"


@interface ViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
{
    UICollectionView *_collectionView;
    NSMutableArray *_dateArrey;
    
}
@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self createcollectionView];
}
-(void)createcollectionView
{
    CatFlowLayout *flowLayout = [[CatFlowLayout alloc]init];
    flowLayout.naviHeight = 0;
    flowLayout.allItems = NO;//设置是否全部悬浮
    flowLayout.itemNum = 2;//第3个悬浮
    
    
    _collectionView = [[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:flowLayout];
    _collectionView.backgroundColor = [UIColor clearColor];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
//    _collectionView.showsVerticalScrollIndicator = NO;
//    _collectionView.alwaysBounceVertical = YES;
    [self.view addSubview:_collectionView];
    
    [_collectionView registerClass:[CollectionViewCell class] forCellWithReuseIdentifier:@"cellId"];
    
    [_collectionView registerClass:[CollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerId"];
    
    
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 11;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section == 6) {
        return 0;
    }
    if (section == 10){
        return 101;
    }
    return 51;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellId" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor lightGrayColor];
    cell.label.text = [NSString stringWithFormat:@"%ld",indexPath.row];
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    
    CollectionReusableView *head = [collectionView  dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerId" forIndexPath:indexPath];
    head.imageView.backgroundColor = [UIColor colorWithRed:0.1 green:0.8 blue:0.4 alpha:0.4];
    head.label.text = [NSString stringWithFormat:@"第%ld个区头",indexPath.section];
    return head;
 
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    
    return CGSizeMake(self.view.frame.size.width, 100);
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
